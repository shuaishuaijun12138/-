<template>
    <div>我是about关于我们</div>
</template>

<script>
export default {
  name: 'About'
}
</script>

<style scoped>
    div {
        background-color: #ff0;
        height: 100px;
    }
</style>
