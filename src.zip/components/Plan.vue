<template>
    <div>我是解决方案plan</div>
</template>

<script>
export default {
  name: 'Plan'
}
</script>

<style scoped>
    div {
        background-color: #ff0;
        height: 100px;
    }
</style>
