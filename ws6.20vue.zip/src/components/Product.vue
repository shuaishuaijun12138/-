<template>
    <div>我是Product核心业务</div>
</template>

<script>
export default {
  name: 'Product'
}
</script>

<style scoped>
    div {
        background-color: #ff0;
        height: 100px;
    }
</style>
