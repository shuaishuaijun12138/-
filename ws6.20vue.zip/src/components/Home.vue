<template>
    <div>我是首页home</div>
</template>

<script>
export default {
  name: 'Home'
}
</script>

<style scoped>
    div {
        background-color: #ff0;
        height: 100px;
    }
</style>
